<?php 

$servername = "127.0.0.1"; // Als we hosten op domein moet het anders natuurlijk!!
$username = "c3687thewall";
$password = "KQvhtfP65_";
$dbname = "c3687thewall";

$conn = mysqli_connect($servername, $username, $password, $dbname);